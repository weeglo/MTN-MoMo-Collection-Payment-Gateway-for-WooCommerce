<?php
/*
Plugin Name: WC MTN MoMo Collection Payment Gateway
Description: Enables MTN MoMo Collection Payment for WooCommerce by Weeglo.
Version:     1.2.0
Author:      Weeglo Team
Author URI:  https://www.weeglo.io
Text Domain: wc-weeglo-pg
Domain Path: /languages
*/

defined( 'ABSPATH' ) or die;

define( 'WC_WEEGLO_PG_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'WC_WEEGLO_PG_CLASS_PATH', trailingslashit( WC_WEEGLO_PG_PLUGIN_PATH . 'classes' ) );
define( 'WC_WEEGLO_PG_VER', '1.2.0' );

if ( ! class_exists( 'WC_Weeglo_PG_Wrapper' ) ) {
    class WC_Weeglo_PG_Wrapper {
        public static function getInstance() {
            if ( self::$instance == null ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private $inc_dir = null;

        private static $instance = null;

        private function __clone() { }

        private function __wakeup() { }

        private function __construct() {
            // Properties

            // Hooks
            add_action( 'plugins_loaded', array( $this, 'check_for_woocommerce' ) );
			add_action( 'wp_ajax_wc_weeglo_pg_form', array( $this, 'form' ) );
			add_action( 'wp_ajax_nopriv_wc_weeglo_pg_form', array( $this, 'form' ) );
			add_action( 'wp_ajax_wc_weeglo_pg_sign_in', array( $this, 'sign_in' ) );
			add_action( 'wp_ajax_nopriv_wc_weeglo_pg_sign_in', array( $this, 'sign_in' ) );
			add_action( 'wp_ajax_wc_weeglo_pg_sign_up', array( $this, 'sign_up' ) );
			add_action( 'wp_ajax_nopriv_wc_weeglo_pg_sign_up', array( $this, 'sign_up' ) );
			add_action( 'wp_ajax_wc_weeglo_pg_check_transaction', array( $this, 'check_tx' ) );
			add_action( 'wp_ajax_nopriv_wc_weeglo_pg_check_transaction', array( $this, 'check_tx' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        }

        public function check_for_woocommerce() {
            if ( ! class_exists( 'WooCommerce' ) ) {
                add_action( 'admin_notices', array( $this, 'missing_wc_notice' ) );
                return;
            }

            define( 'WC_WEEGLO_PG_BASE_FILE', __FILE__ );

            require_once( WC_WEEGLO_PG_CLASS_PATH . 'class-wc-weeglo-pg.php' );

            add_filter( 'woocommerce_payment_gateways', array( $this, 'load_gateway_class' ) );
        }

        public function missing_wc_notice() {
            echo '<div class="error"><p><strong>' . sprintf( esc_html__( 'Weeglo Payment Gateway requires WooCommerce to be installed and active. You can download %s here.', 'wc-weeglo-pg' ), '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>' ) . '</strong></p></div>';
        }

        public function load_gateway_class( $methods ) {
            $methods[] = 'WC_Weeglo_PG';
            return $methods;
        }

		public function form() {
			$order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;
			if ( ! $order_id ) wp_die( __( 'Invalid Order', 'wc-weeglo-pg' ) );

			$order = wc_get_order( $order_id );
			if ( ! $order ) wp_die( __( 'Invalid order', 'wc-weeglo-pg' ) );

			$is_paid = ( int ) get_post_meta( $order_id, '_weeglo_paid', true );
			if ( $is_paid ) wp_die( __( 'Invalid request', 'wc-weeglo-pg' ) );

			if ( $order->get_user_id() != get_current_user_id() ) wp_die( __( 'Invalid request', 'wc-weeglo-pg' ) );

			require( WC_WEEGLO_PG_PLUGIN_PATH . 'form.php' );
			die;
		}

		public function sign_up() {
			$email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
			if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) wp_send_json_error( __( 'Invalid e-mail address', 'wc-weeglo-pg' ) );

			$password = isset( $_POST['password'] ) ? sanitize_text_field( $_POST['password'] ) : '';
			if ( $password === '' ) wp_send_json_error( __( 'Invalid password', 'wc-weeglo-pg' ) );

			$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
			if ( ! $order_id ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			$phone = get_post_meta( $order_id, '_weeglo_phone', true );

			$order = wc_get_order( $order_id );
			if ( ! $order ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			if ( $order->get_user_id() != get_current_user_id() ) wp_send_json_error( __( 'Invalid request', 'wc-weeglo-pg' ) );

			$that = new WC_Weeglo_PG;
			$result = $that->sign_up( $email, $phone, $password, $order->get_user_id() );

			if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );

			wp_send_json_success( $email );
		}

		public function sign_in() {
			$email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
			if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) wp_send_json_error( __( 'Invalid e-mail address', 'wc-weeglo-pg' ) );

			$password = isset( $_POST['password'] ) ? sanitize_text_field( $_POST['password'] ) : '';
			if ( $password === '' ) wp_send_json_error( __( 'Invalid password', 'wc-weeglo-pg' ) );

			$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
			if ( ! $order_id ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			$order = wc_get_order( $order_id );
			if ( ! $order ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			if ( $order->get_user_id() != get_current_user_id() ) wp_send_json_error( __( 'Invalid request', 'wc-weeglo-pg' ) );

			$that = new WC_Weeglo_PG;
			$token = $that->sign_in( $email, $password );

			if ( is_wp_error( $token ) ) wp_send_json_error( $token->get_error_message() );

			// Payment request
			$result = $that->send_payment_request( $email, $password, $token, $order->get_user_id(), $order_id );

			if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );
			if ( ! property_exists( $result, 'referenceUuid' ) ) wp_send_json_error( __( 'referenceUuid not present in response.', 'wc-weeglo-pg' ) );
			if ( ! property_exists( $result, 'transaction' ) ) wp_send_json_error( __( 'transaction not present in response.', 'wc-weeglo-pg' ) );

			update_post_meta( $order_id, '_weeglo_transaction', $result );
			update_post_meta( $order_id, '_weeglo_transaction_id', $result->referenceUuid );
			update_post_meta( $order_id, '_weeglo_token', $token );

			$order->add_order_note( sprintf( __( 'Weeglo transaction created, referenceUuid: %s', 'wc-weeglo-pg' ), $result->referenceUuid ) );

			if ( $result->transaction->status == "PENDING" ) {
				$order->update_status( 'pending' );
				wp_send_json_success( array( 'refresh' => 30000 ) );
			} elseif ( $result->transaction->status == "SUCCESSFUL" ) {
				$order->payment_complete();
				wp_send_json_success( array( 'redirect' => $that->get_return_url( $order ) ) );
			} else {
				$order->update_status( 'cancelled', __( 'Order cancelled', 'wc-weeglo-pg' ) );
				wp_send_json_success( array( 'redirect' => wc_get_checkout_url() ) );
			}
		}

		public function check_tx() {
			$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
			if ( ! $order_id ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			$order = wc_get_order( $order_id );
			if ( ! $order ) wp_send_json_error( __( 'Invalid order', 'wc-weeglo-pg' ) );

			if ( $order->get_user_id() != get_current_user_id() ) wp_send_json_error( __( 'Invalid request', 'wc-weeglo-pg' ) );

			$that = new WC_Weeglo_PG;
			$result = $that->check_transaction_status( get_post_meta( $order_id, '_weeglo_transaction_id', true ), get_post_meta( $order_id, '_weeglo_token', true ) );

			if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );
			if ( ! property_exists( $result, 'status' ) ) wp_send_json_error( __( 'status not present in response.', 'wc-weeglo-pg' ) );

			if ( $result->status == "PENDING" ) {
				wp_send_json_success( array( 'refresh' => 30000 ) );
			} elseif ( $result->status == "SUCCESSFUL" ) {
				$order->add_order_note( sprintf( __( 'Weeglo transaction: payment success', 'wc-weeglo-pg' ) ) );
				$order->payment_complete();
				wp_send_json_success( array( 'redirect' => $that->get_return_url( $order ) ) );
			} else {
				$order->add_order_note( sprintf( __( 'Weeglo transaction cancelled', 'wc-weeglo-pg' ) ) );
				$order->update_status( 'cancelled', __( 'Order cancelled', 'wc-weeglo-pg' ) );
				wp_send_json_success( array( 'redirect' => wc_get_checkout_url() ) );
			}
		}

		public function enqueue_assets() {
			if ( function_exists( 'is_checkout' ) && is_checkout() ) {
				wp_enqueue_style( 'wc-weeglo-pg-style', plugins_url( 'css/style.css', __FILE__ ), array(), WC_WEEGLO_PG_VER, 'all' );
			}
		}
    }
}
WC_Weeglo_PG_Wrapper::getInstance();
