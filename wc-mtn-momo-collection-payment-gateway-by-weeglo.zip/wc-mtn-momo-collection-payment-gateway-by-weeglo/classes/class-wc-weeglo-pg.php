<?php
defined( 'ABSPATH' ) or die();

if ( ! class_exists( 'WC_Weeglo_PG' ) ) {
	class WC_Weeglo_PG extends WC_Payment_Gateway {
		public function __construct() {
			// Properties
			$this->id                 = 'weeglo_pg';
			$this->icon               = plugins_url( 'images/logo.png', WC_WEEGLO_PG_BASE_FILE );
			$this->description        = __( 'Pay with Weeglo', 'wc-weeglo-pg' );
			$this->order_button_text  = __( 'Confirm', 'wc-weeglo-pg' );
			$this->has_fields         = true;
			$this->title              = 'Weeglo';
			$this->method_title       = 'Weeglo';
			$this->method_description = __( 'Weeglo - A Secure Interface for Web3 and Mobile Money Application Development.', 'wc-weeglo-pg' );
			$this->api_urls           = array(
											'endpoint_url' => 'https://www.api.weeglo.io/api/v1/',
											'base_url' => 'production'
										);
			$this->sb_api_urls        = array(
											'endpoint_url' => 'https://www.api.weeglo.io/api/v1/',
											'base_url' => 'sandbox'
										);

			// Methods
			$this->init_form_fields();
			$this->init_settings();

			// Initialize some properties
			if( $this->get_option( 'sb_mode' ) == 'yes' ) {
				$this->api_urls = $this->sb_api_urls;
			}

			// Hooks
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}

		public function init_form_fields() {
			$this->form_fields = array(
				'enabled' => array(
					'title'       => __( 'Enable/Disable', 'wc-weeglo-pg' ),
					'type'        => 'checkbox',
					'label'       => __( 'Enable Weeglo Payment Method', 'wc-weeglo-pg' ),
					'default'     => 'yes'
				),
				'title' => array(
					'title'       => __( 'Title', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'This controls the title which the user sees during checkout.', 'wc-weeglo-pg' ),
					'default'     => __( 'Weeglo', 'wc-weeglo-pg' ),
					'desc_tip'    => true
				),
				'mobile' => array(
					'title'       => __( 'Mobile', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Weeglo\'s associated Mobile Number.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'    => true
				),
				'user_id' => array(
					'title'       => __( 'User Id', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Weeglo\'s User id.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'     => true
				),
				'subscription_primary_key' => array(
					'title'       => __( 'Subscription Primary Key', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Subscription Primary Key.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'     => true
				),
				'subscription_secondary_key' => array(
					'title'       => __( 'Subscription Secondary Key', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Subscription Secondary Key.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'     => true
				),
				'api_key' => array(
					'title'       => __( 'Api Key', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Api Key.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'     => true
				),
				'tenant_key' => array(
					'title'       => __( 'Tenant Key', 'wc-weeglo-pg' ),
					'type'        => 'text',
					'description' => __( 'Your Tenant Key.', 'wc-weeglo-pg' ),
					'default'     => '',
					'desc_tip'     => true
				),
				'sb_mode'     => array(
					'title'       => __( 'Sandbox Mode', 'wc-weeglo-pg' ),
					'label'       => __( 'Enabled', 'wc-weeglo-pg' ),
					'type'        => 'checkbox',
					'default'     => '',
				)
			);
		}

		public function payment_fields() {
			echo '<div class="wc-weeglo-checkout-fields"><label for="weeglo_mobile">' . __( 'Mobile Number', 'wc-weeglo-pg' ) . '</label><div class="InputAddOn"><input type="phone" name="weeglo_mobile" autocomplete="off"></div><small>' . __( 'Example: 0770808291', 'wc-weeglo-pg' )  . '</small></div>';
		}

		public function validate_fields() {
			if ( ! isset( $_POST['weeglo_mobile'] ) ) {
				wc_add_notice( __( 'Missing Mobile Number.', 'wc-weeglo-pg' ), 'error' );
				return false;
			}

			if ( $_POST['weeglo_mobile']  === '' ) {
				wc_add_notice( __( 'Invalid Mobile Number.', 'wc-weeglo-pg' ), 'error' );
				return false;
			}

			return true;
		}

		public function process_payment( $order_id ) {
			global $woocommerce;

			update_post_meta( $order_id, '_weeglo_phone', $_POST['weeglo_mobile'] );
			//$order->update_status( 'pending', __( 'Pending payment', 'wc-weeglo-pg' ) );

			return array(
				'result' => 'success',
				'redirect' => admin_url( 'admin-ajax.php?action=wc_weeglo_pg_form&order_id=' . $order_id )
			);
		}

		public function sign_in( $email, $password ) {
			$response = $this->request( 'user_token/', array(), array(
				'auth' => array(
					'email' => $email,
					'password' => $password
				)
			) );

			if ( is_wp_error( $response ) ) return $response;

			$obj = @json_decode( $response['body'] );
			if ( ! $obj ) return new WP_Error( 'error', __( 'Server error or invalid email/password', 'wc-weeglo-pg' ) );

			if ( ! property_exists( $obj, 'jwt' ) ) return new WP_Error( 'error', print_r( $obj, true ) );

			return $obj->jwt;
		}

		public function sign_up( $email, $phone, $password, $customer_id ) {
			$address_1 = get_user_meta( $customer_id, 'billing_address_1', true );
			$address_2 = get_user_meta( $customer_id, 'billing_address_2', true );

			$response = $this->request( 'users/', array(), array(
				'user' => array(
					'email' => $email,
					'phone' => $phone,
					'first_name' => get_user_meta( $customer_id, 'billing_first_name', true ),
					'last_name' => get_user_meta( $customer_id, 'billing_last_name', true ),
					'street_address' => $address_1 . ( $address_2 == '' ? '' : ", $address_2" ),
					'city' => get_user_meta( $customer_id, 'billing_city', true ),
					'country' => $this->get_a3_cc( get_user_meta( $customer_id, 'billing_country', true ) ),
					'password' => $password,
					'password_confirmation' => $password
				)
			) );

			if ( is_wp_error( $response ) ) return $response;
			if ( $response['response']['code'] != 200 ) return new WP_Error( 'error', __( 'Server error or email/phone already registered', 'wc-weeglo-pg' ) );

			return true;
		}

		public function send_payment_request( $email, $password, $token, $customer_id, $order_id ) {
			$order = new WC_Order( $order_id );
			$total = number_format( $order->get_total(), 2, '.', '' );
			$currency = $this->get_option( 'sb_mode' ) == 'yes' ? 'EUR' : $order->get_currency();

			$headers = array(
				'Authorization' => "Bearer $token"
			);

			$result = $this->request( 'collects/', $headers, array(
				'collect' => array(
					'txPayerPhone' => get_post_meta( $order_id, '_weeglo_phone', true ),
					//'txPayeePhone' => $this->get_option( 'mobile' ),
					'txAmount' => $total,
					'txCurrency' => $currency,
					'txPayeeNote' => sprintf( __( 'Receiving payment for order No%d', 'wc-weeglo-pg' ), $order_id ),
					'txPayerMessage' => sprintf( __( 'Paying for order No%d', 'wc-weeglo-pg' ), $order_id ),
					'txBaseUrl' => $this->api_urls['base_url'],
					'txCallbackHost' => get_rest_url() . 'weeglo_gateway/v1/ppc/' . $order_id,
					'txCollectionPrimaryKey' => $this->get_option( 'subscription_primary_key' ),
					'txCollectionUserId' => $this->get_option( 'user_id' ),
					'txCollectionApiSecret' => $this->get_option( 'api_key' ),
					'AssignedTenantKey' => $this->get_option( 'tenant_key' )
				)
			) );

			if ( is_wp_error( $result ) ) return $result;

			if ( $result['response']['code'] != 200 ) return new WP_Error( 'error', __( 'Payment failed, please try again later or contact the website administrator.', 'wc-weeglo-pg' ) );

			$obj = json_decode( $result['body'] );
			if ( ! $obj ) return new WP_Error( 'error', __( 'Invalid server response.', 'wc-weeglo-pg' ) );

			return $obj;
		}

		public function check_transaction_status( $transaction_id, $token ) {
			$headers = array(
				'Authorization' => "Bearer $token"
			);

			$result = $this->request( 'transaction_status_checks/', $headers, array(
				'transaction_status_check' => array(
					'txType' => 'collection',
					'txBaseUrl' => $this->api_urls['base_url'],
					'txCallbackHost' => get_rest_url() . 'weeglo_gateway/v1/ppc/' . $order_id,
					'txReferenceUuid' => $transaction_id,
					'txPrimaryKey' => $this->get_option( 'subscription_primary_key' ),
					'txUserId' => $this->get_option( 'user_id' ),
					'txApiSecret' => $this->get_option( 'api_key' ),
					'AssignedTenantKey' => $this->get_option( 'tenant_key' )
				)
			) );

			if ( is_wp_error( $result ) ) return $result;

			if ( $result['response']['code'] != 200 ) return new WP_Error( 'error', __( 'Transaction verification failed, please contact the website administrator.', 'wc-weeglo-pg' ) );

			$obj = json_decode( $result['body'] );
			if ( ! $obj ) return new WP_Error( 'error', __( 'Invalid server response.', 'wc-weeglo-pg' ) );

			return $obj;
		}

		private function request( $route, $headers, $payload ) {
			$headers['Content-Type'] = 'application/json';

			return wp_remote_post( $this->api_urls['endpoint_url'] . $route, array(
				'method'      => 'POST',
				'timeout'     => 45,
				'redirection' => 5,
				'httpversion' => '1.0',
				'blocking'    => true,
				'headers'     => $headers,
				'body'        => json_encode( $payload )
			) );
		}

		private function get_a3_cc( $code ) {
			$countries = array( 'AF' => 'AFG', 'AX' => 'ALA', 'AL' => 'ALB', 'DZ' => 'DZA', 'AS' => 'ASM', 'AD' => 'AND', 'AO' => 'AGO', 'AI' => 'AIA', 'AQ' => 'ATA', 'AG' => 'ATG', 'AR' => 'ARG', 'AM' => 'ARM', 'AW' => 'ABW', 'AU' => 'AUS', 'AT' => 'AUT', 'AZ' => 'AZE', 'BS' => 'BHS', 'BH' => 'BHR', 'BD' => 'BGD', 'BB' => 'BRB', 'BY' => 'BLR', 'BE' => 'BEL', 'BZ' => 'BLZ', 'BJ' => 'BEN', 'BM' => 'BMU', 'BT' => 'BTN', 'BO' => 'BOL', 'BQ' => 'BES', 'BA' => 'BIH', 'BW' => 'BWA', 'BV' => 'BVT', 'BR' => 'BRA', 'IO' => 'IOT', 'BN' => 'BRN', 'BG' => 'BGR', 'BF' => 'BFA', 'BI' => 'BDI', 'KH' => 'KHM', 'CM' => 'CMR', 'CA' => 'CAN', 'CV' => 'CPV', 'KY' => 'CYM', 'CF' => 'CAF', 'TD' => 'TCD', 'CL' => 'CHL', 'CN' => 'CHN', 'CX' => 'CXR', 'CC' => 'CCK', 'CO' => 'COL', 'KM' => 'COM', 'CG' => 'COG', 'CD' => 'COD', 'CK' => 'COK', 'CR' => 'CRI', 'CI' => 'CIV', 'HR' => 'HRV', 'CU' => 'CUB', 'CW' => 'CUW', 'CY' => 'CYP', 'CZ' => 'CZE', 'DK' => 'DNK', 'DJ' => 'DJI', 'DM' => 'DMA', 'DO' => 'DOM', 'EC' => 'ECU', 'EG' => 'EGY', 'SV' => 'SLV', 'GQ' => 'GNQ', 'ER' => 'ERI', 'EE' => 'EST', 'ET' => 'ETH', 'FK' => 'FLK', 'FO' => 'FRO', 'FJ' => 'FIJ', 'FI' => 'FIN', 'FR' => 'FRA', 'GF' => 'GUF', 'PF' => 'PYF', 'TF' => 'ATF', 'GA' => 'GAB', 'GM' => 'GMB', 'GE' => 'GEO', 'DE' => 'DEU', 'GH' => 'GHA', 'GI' => 'GIB', 'GR' => 'GRC', 'GL' => 'GRL', 'GD' => 'GRD', 'GP' => 'GLP', 'GU' => 'GUM', 'GT' => 'GTM', 'GG' => 'GGY', 'GN' => 'GIN', 'GW' => 'GNB', 'GY' => 'GUY', 'HT' => 'HTI', 'HM' => 'HMD', 'VA' => 'VAT', 'HN' => 'HND', 'HK' => 'HKG', 'HU' => 'HUN', 'IS' => 'ISL', 'IN' => 'IND', 'ID' => 'IDN', 'IR' => 'IRN', 'IQ' => 'IRQ', 'IE' => 'IRL', 'IM' => 'IMN', 'IL' => 'ISR', 'IT' => 'ITA', 'JM' => 'JAM', 'JP' => 'JPN', 'JE' => 'JEY', 'JO' => 'JOR', 'KZ' => 'KAZ', 'KE' => 'KEN', 'KI' => 'KIR', 'KP' => 'PRK', 'KR' => 'KOR', 'KW' => 'KWT', 'KG' => 'KGZ', 'LA' => 'LAO', 'LV' => 'LVA', 'LB' => 'LBN', 'LS' => 'LSO', 'LR' => 'LBR', 'LY' => 'LBY', 'LI' => 'LIE', 'LT' => 'LTU', 'LU' => 'LUX', 'MO' => 'MAC', 'MK' => 'MKD', 'MG' => 'MDG', 'MW' => 'MWI', 'MY' => 'MYS', 'MV' => 'MDV', 'ML' => 'MLI', 'MT' => 'MLT', 'MH' => 'MHL', 'MQ' => 'MTQ', 'MR' => 'MRT', 'MU' => 'MUS', 'YT' => 'MYT', 'MX' => 'MEX', 'FM' => 'FSM', 'MD' => 'MDA', 'MC' => 'MCO', 'MN' => 'MNG', 'ME' => 'MNE', 'MS' => 'MSR', 'MA' => 'MAR', 'MZ' => 'MOZ', 'MM' => 'MMR', 'NA' => 'NAM', 'NR' => 'NRU', 'NP' => 'NPL', 'NL' => 'NLD', 'AN' => 'ANT', 'NC' => 'NCL', 'NZ' => 'NZL', 'NI' => 'NIC', 'NE' => 'NER', 'NG' => 'NGA', 'NU' => 'NIU', 'NF' => 'NFK', 'MP' => 'MNP', 'NO' => 'NOR', 'OM' => 'OMN', 'PK' => 'PAK', 'PW' => 'PLW', 'PS' => 'PSE', 'PA' => 'PAN', 'PG' => 'PNG', 'PY' => 'PRY', 'PE' => 'PER', 'PH' => 'PHL', 'PN' => 'PCN', 'PL' => 'POL', 'PT' => 'PRT', 'PR' => 'PRI', 'QA' => 'QAT', 'RE' => 'REU', 'RO' => 'ROU', 'RU' => 'RUS', 'RW' => 'RWA', 'BL' => 'BLM', 'SH' => 'SHN', 'KN' => 'KNA', 'LC' => 'LCA', 'MF' => 'MAF', 'SX' => 'SXM', 'PM' => 'SPM', 'VC' => 'VCT', 'WS' => 'WSM', 'SM' => 'SMR', 'ST' => 'STP', 'SA' => 'SAU', 'SN' => 'SEN', 'RS' => 'SRB', 'SC' => 'SYC', 'SL' => 'SLE', 'SG' => 'SGP', 'SK' => 'SVK', 'SI' => 'SVN', 'SB' => 'SLB', 'SO' => 'SOM', 'ZA' => 'ZAF', 'GS' => 'SGS', 'SS' => 'SSD', 'ES' => 'ESP', 'LK' => 'LKA', 'SD' => 'SDN', 'SR' => 'SUR', 'SJ' => 'SJM', 'SZ' => 'SWZ', 'SE' => 'SWE', 'CH' => 'CHE', 'SY' => 'SYR', 'TW' => 'TWN', 'TJ' => 'TJK', 'TZ' => 'TZA', 'TH' => 'THA', 'TL' => 'TLS', 'TG' => 'TGO', 'TK' => 'TKL', 'TO' => 'TON', 'TT' => 'TTO', 'TN' => 'TUN', 'TR' => 'TUR', 'TM' => 'TKM', 'TC' => 'TCA', 'TV' => 'TUV', 'UG' => 'UGA', 'UA' => 'UKR', 'AE' => 'ARE', 'GB' => 'GBR', 'US' => 'USA', 'UM' => 'UMI', 'UY' => 'URY', 'UZ' => 'UZB', 'VU' => 'VUT', 'VE' => 'VEN', 'VN' => 'VNM', 'VG' => 'VGB', 'VI' => 'VIR', 'WF' => 'WLF', 'EH' => 'ESH', 'YE' => 'YEM', 'ZM' => 'ZMB', 'ZW' => 'ZWE', ); $iso_code = isset( $countries[$code] ) ? $countries[$code] : $code; return $iso_code;
		}
	}
}