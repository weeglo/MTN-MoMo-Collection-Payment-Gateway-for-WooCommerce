<!DOCTYPE html>
<html>
	<head>
		<title><?php echo sprintf( __( 'Pay with Weeglo - Order %d', 'wc-weeglo-pg' ), $order_id ); ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo plugins_url( 'css/bootstrap.min.css', WC_WEEGLO_PG_BASE_FILE ); ?>">
		<style type="text/css">
			.doing-ajax .d-none {
				display: block !important;
			}
			#signup_form {
				display: none;
			}
			.awaiting-payment {
				text-align: center;
				display: none;
				font-size: 1.5em;
				font-weight: bold;
			}
			.doing-ajax-2 .awaiting-payment {
				display: block;
			}
		</style>
	</head>
	<body class="mt-4">
		<div class="container">
			<div class="row">
				<div class="col">
					<form id="signin_form">
						<div class="mb-3">
							<h3><?php _e( 'Proceed to Weeglo' ); ?></h3>
						</div>
						<div class="mb-3">
							<label for="email" class="form-label"><?php _e( 'E-mail', 'wc-weeglo-pg' ); ?></label>
							<input type="text" class="form-control email" name="email" value="<?php esc_attr_e( get_user_meta( $order->get_user_id(), 'billing_email', true ) ); ?>" autocomplete="off">
						</div>
						<div class="mb-3">
							<label for="password" class="form-label"><?php _e( 'Password', 'wc-weeglo-pg' ); ?></label>
							<input type="password" class="form-control password" name="password">
						</div>
						<div class="mb-3">
							<?php echo sprintf( __( 'Not registered? %sSign up%s', 'wc-weeglo-pg' ), '<a class="show-su-form" href="#">', '</a>' ); ?></a>
						</div>
						<button type="submit" class="form-control btn btn-success mb-3"><?php _e( 'Sign In and Pay', 'wc-weeglo-pg' ); ?></button>
						<a href="<?php esc_attr_e( wc_get_checkout_url() ); ?>" class="btn btn-danger w-100"><?php _e( 'Cancel', 'wc-weeglo-pg' ); ?></a>
					</form>
					<form id="signup_form">
						<div class="mb-3">
							<h3><?php _e( 'Sign up to Weeglo' ); ?></h3>
						</div>
						<div class="mb-3">
							<label for="email" class="form-label"><?php _e( 'E-mail', 'wc-weeglo-pg' ); ?></label>
							<input type="text" class="form-control email" name="email" value="<?php esc_attr_e( get_user_meta( $order->get_user_id(), 'billing_email', true ) ); ?>" autocomplete="off">
						</div>
						<div class="mb-3">
							<label for="phone" class="form-label"><?php _e( 'Phone Number', 'wc-weeglo-pg' ); ?></label>
							<input type="text" class="form-control phone" name="phone" value="<?php esc_attr_e( get_post_meta( $order->get_id(), '_weeglo_phone', true ) ); ?>" disabled autocomplete="off">
						</div>
						<div class="mb-3">
							<label for="password" class="form-label"><?php _e( 'Password', 'wc-weeglo-pg' ); ?></label>
							<input type="password" class="form-control password" name="password">
						</div>
						<div class="mb-3">
							<label for="password2" class="form-label"><?php _e( 'Confirm Password', 'wc-weeglo-pg' ); ?></label>
							<input type="password" class="form-control password2" name="password2">
						</div>
						<div class="mb-3">
							<?php echo sprintf( __( 'Already registered? %sSign in%s', 'wc-weeglo-pg' ), '<a href="#" class="show-si-form">', '</a>' ); ?></a>
						</div>
						<button type="submit" class="form-control btn btn-success mb-3"><?php _e( 'Sign Up', 'wc-weeglo-pg' ); ?></button>
						<a href="<?php esc_attr_e( wc_get_checkout_url() ); ?>" class="btn btn-danger w-100"><?php _e( 'Cancel', 'wc-weeglo-pg' ); ?></a>
					</form>
					<div class="mt-4 mx-auto text-center d-none">
						<div class="spinner-border" role="status">
							<span class="sr-only"></span>
						</div>
					</div>
					<div class="awaiting-payment"><?php _e( 'Awaiting Payment confirmation...', 'wc-weeglo-pg' ); ?></div>
				</div>
			</div>
		</div>
		<script src="<?php echo plugins_url( 'js/jquery-1.12.4.min.js', WC_WEEGLO_PG_BASE_FILE ); ?>"></script>
		<script>
			(function($) {
				function refresh() {
					$.ajax({
						type: "POST",
						url: "<?php esc_attr_e( admin_url( 'admin-ajax.php?action=wc_weeglo_pg_check_transaction' ) ); ?>",
						cache: false,
						dataType: "json",
						data: {
							order_id: <?php echo $order_id; ?>
						}
					}).done(function(response) {
						if(response.success) {
							if(response.data.refresh) {
								setTimeout(refresh, response.data.refresh);
							} else {
								document.location.href = response.data.redirect;
							}
						} else {
							alert(response.data);
							container.removeClass("doing-ajax doing-ajax-2");
						}
					}).fail(function() {
						alert("<?php esc_attr_e( 'Network/Server Error', 'wc-weeglo-pg' ); ?>");
						container.removeClass("doing-ajax doing-ajax-2");
					});
				}

				$(".show-su-form").on("click", function(e) {
					e.preventDefault();
					$("#signin_form").toggle(300, function() {
						$("#signup_form").toggle(700);
					});
				});

				$(".show-si-form").on("click", function(e) {
					e.preventDefault();
					$("#signup_form").toggle(300, function() {
						$("#signin_form").toggle(300);
					});
				});

				$("#signin_form").on("submit", function(e) {
					e.preventDefault();
					var form = $(this);
					var container = form.closest(".container");
					var email = form.find("input.email").val().toString().trim();
					var password = form.find("input.password").val().toString().trim();

					if(email == "") return false;
					if(password == "") return false;
					if(container.hasClass("doing-ajax")) return false;

					container.addClass("doing-ajax");
					$.ajax({
						type: "POST",
						url: "<?php esc_attr_e( admin_url( 'admin-ajax.php?action=wc_weeglo_pg_sign_in' ) ); ?>",
						cache: false,
						dataType: "json",
						data: {
							order_id: <?php echo $order_id; ?>,
							email: email,
							password: password
						}
					}).done(function(response) {
						if(response.success) {
							container.addClass("doing-ajax-2");
							if(response.data.refresh) {
								setTimeout(refresh, response.data.refresh);
							} else {
								document.location.href = response.data.redirect;
							}
						} else {
							alert(response.data);
							container.removeClass("doing-ajax");
						}
					}).fail(function() {
						alert("<?php esc_attr_e( 'Network/Server Error', 'wc-weeglo-pg' ); ?>");
						container.removeClass("doing-ajax");
					});
				});

				$("#signup_form").on("submit", function(e) {
					e.preventDefault();
					var form = $(this);
					var container = form.closest(".container");
					var email = form.find("input.email").val().toString().trim();
					var phone = form.find("input.phone").val().toString().trim();
					var password = form.find("input.password").val().toString().trim();
					var password2 = form.find("input.password2").val().toString().trim();

					if(email == "") return false;
					if(password == "") return false;
					if(password != password2) {
						alert("<?php esc_attr_e( 'Passwords do not match!', 'wc-weeglo-pg' ); ?>");
						return false;
					}
					if(container.hasClass("doing-ajax")) return false;

					container.addClass("doing-ajax");
					$.ajax({
						type: "POST",
						url: "<?php esc_attr_e( admin_url( 'admin-ajax.php?action=wc_weeglo_pg_sign_up' ) ); ?>",
						cache: false,
						dataType: "json",
						data: {
							order_id: <?php echo $order_id; ?>,
							email: email,
							phone: phone,
							password: password
						}
					}).done(function(response) {
						if(response.success) {
							alert("<?php esc_attr_e( 'User successfully created! Please sign in now.', 'wc-weeglo-pg' ); ?>");
							$("#signup_form").toggle(300, function() {
								$("#signin_form").toggle(300);
							});
						} else {
							alert(response.data);
						}
						container.removeClass("doing-ajax");
					}).fail(function() {
						alert("<?php esc_attr_e( 'Network/Server Error', 'wc-weeglo-pg' ); ?>");
						container.removeClass("doing-ajax");
					});
				});
			})(jQuery);
		</script>
	</body>
</html>